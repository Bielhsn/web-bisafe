from flask import Flask, request, jsonify
import cv2
import numpy as np
import tensorflow as tf
import os
from werkzeug.utils import secure_filename

from flask import Flask, request, jsonify
from flask_cors import CORS

app = Flask(__name__)
CORS(app)  # Configuração do CORS

# Carregue o modelo de rede neural.
model = tf.keras.models.load_model('C:/Users/Pichau/Desktop/modelo.h5')

UPLOAD_FOLDER = 'uploads' #cria uma pasta e salva aqui nessa pasta as imagens de bike
ALLOWED_EXTENSIONS = {'jpg', 'jpeg', 'png'}

app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def preprocess_image(image):
    # Converta a imagem para um formato que o modelo possa entender.
    image = cv2.resize(image, (224, 224))
    image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
    image = np.expand_dims(image, axis=0)

    return image

# Rota para receber os dados e fazer previsões
@app.route('/prever', methods=['POST'])
def prever():
    try:
        frontal = request.files['frontal']
        traseira = request.files['traseira']
        lateral = request.files['lateral']

        response = {}

        if frontal and traseira and lateral:
            # Processar imagens separadamente
            for image_type, image_file in [('frontal', frontal), ('traseira', traseira), ('lateral', lateral)]:
                if image_file and allowed_file(image_file.filename):
                    # Salvar a imagem temporariamente
                    filename = secure_filename(image_file.filename)
                    image_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
                    image_file.save(image_path)

                    # Carregar a imagem
                    image = cv2.imread(image_path)

                    # Pré-processar a imagem
                    image = preprocess_image(image)

                    # Fazer previsões usando o modelo
                    prediction = model.predict(image)

                    # Determinar se a imagem é uma bicicleta ou não
                    is_bike = prediction[0][0] > prediction[0][1]
                    response[image_type] = f'{image_type} reconhecida com sucesso' if is_bike else f'{image_type} não reconhecida, tente novamente com outra imagem'

                else:
                    response[image_type] = f'Nenhuma imagem válida para {image_type}'

            return jsonify(response)
        else:
            return jsonify({'error': 'Nenhuma imagem recebida na solicitação POST.'}), 400
    except Exception as e:
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    print("Servidor Flask em execução")
    os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)
    # Executar o aplicativo Flask
    app.run(debug=True)
